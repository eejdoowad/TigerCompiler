
Testcases contained in directory tests. ParseTable.csv and Agrammar.txt must be in the same directory as the jar.

Examples:

java -jar tigc -h
Shows help info

java -jar tigc.jar tests/test2.tiger -p=ast -g=ast -ast=easy
Prints the AST to stdout and saves it to tests/test2.ast in an visually interpretable format

java -jar tigc.jar tests/test1.tiger -p=ast -ast=sexp
Prints the AST to stdout as an s-expression
